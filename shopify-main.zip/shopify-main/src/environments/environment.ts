export const environment = {
  baseUrlAuth: `https://ecommerce.routemisr.com/api/v1/auth`,
  baseUrlUser: `https://ecommerce.routemisr.com/api/v1`,
  baseUrlData: `https://ecommerce.routemisr.com/api/v1`,
  payUrl: 'https://ahmed-menisy.github.io/FreshCart',
};
