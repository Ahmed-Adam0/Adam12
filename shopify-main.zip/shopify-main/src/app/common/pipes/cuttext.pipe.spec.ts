import { CuttextPipe } from './cuttext.pipe';

describe('CuttextPipe', () => {
  it('create an instance', () => {
    const pipe = new CuttextPipe();
    expect(pipe).toBeTruthy();
  });
});
